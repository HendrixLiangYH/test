# -*- coding: utf-8 -*-
"""
第1步: 网格模拟 → 字典序筛选 → 逐配置稳健性检验 → 降档对照
产出: grid_v26.csv / robust_v26.csv / l4_v26.csv   （约2-3分钟）
"""
import csv
from engine_v26 import *

# ---- 网格 ----
rows = []
for cn, c in CONFIGS.items():
    for w in W_GRID:
        r = sim(c, w); r.update(cfg=cn, w=float(w)); rows.append(r)
with open('grid_v26.csv', 'w', newline='', encoding='utf-8-sig') as f:
    wr = csv.DictWriter(f, fieldnames=['cfg','w','breach','b3','p7','p75','e','trig'])
    wr.writeheader(); wr.writerows(rows)
print(f"[网格] {len(rows)}个格点完成")

# ---- 逐配置稳健性(minimax), 受管理层仓位上限约束, 稳健点间取P(≥7%)最高者 ----
best = None
for cn, c in CONFIGS.items():
    lims = []
    for name, p, ca in SCENARIOS:
        fw = [w for w in W_GRID if sim(c, w, ls=p.get('ls', LS), cush_adj=ca)['breach'] <= PROB_LIMIT]
        lims.append((name, float(max(fw)) if fw else 0.0))
    w_rob = min(min(x for _, x in lims), W_CAP)
    r = [x for x in rows if x['cfg'] == cn and abs(x['w']-w_rob) < 1e-9][0]
    print(f"[稳健] {cn}: 情景上限{[f'{x:.0%}' for _,x in lims]} → 稳健点{w_rob:.0%}  "
          f"击穿{r['breach']:.1%} P(≥7%)={r['p7']:.1%} 期望{r['e']:.2%}")
    if best is None or r['p7'] > best[2]['p7']:
        best = (cn, w_rob, r, lims)
cn, w_rob, r, lims = best
with open('robust_v26.csv', 'w', newline='', encoding='utf-8-sig') as f:
    wr = csv.writer(f); wr.writerow(['情景', '可行最大w']); wr.writerows(lims)
print(f"\n★ 推荐: {cn} 多空{w_rob:.0%} → 击穿{r['breach']:.1%} P(≥7%)={r['p7']:.1%} "
      f"P(≥7.5%)={r['p75']:.1%} 期望{r['e']:.2%} 触发{r['trig']:.1%}")

# ---- 降档有/无对照(推荐配置) ----
c = CONFIGS[cn]; l4 = []
for w in W_GRID:
    a = sim(c, w, use_L4=True); b = sim(c, w, use_L4=False)
    l4.append(dict(w=float(w), b0_on=a['breach'], b0_off=b['breach'], b3_on=a['b3'],
                   b3_off=b['b3'], p7_on=a['p7'], p7_off=b['p7']))
with open('l4_v26.csv', 'w', newline='', encoding='utf-8-sig') as f:
    wr = csv.DictWriter(f, fieldnames=list(l4[0].keys())); wr.writeheader(); wr.writerows(l4)
print(f"[降档对照] 完成; HY独立走阔300bp一次性损失 {0.75*c['why']*D_HY*0.03:.2%} vs 安全垫 {c['cushion']:.2%}")
