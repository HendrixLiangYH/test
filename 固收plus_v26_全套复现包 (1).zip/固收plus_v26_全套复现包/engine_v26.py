# -*- coding: utf-8 -*-
"""
固收+方案 v2.6 —— 共用参数台账与模拟引擎
所有脚本都从这里导入参数与引擎, 改参数只改这一个文件。
成色标注: [A]实测 [B]半实测 [C]量级判断 [D]管理人预期 [设计]产品委员会拍板项
"""
import numpy as np

# ===================== 风险规格（设计参数）=====================
BREACH_LINE = 0.00    # [设计] 击穿判定线: 任一日历年总回报低于此值即击穿
PROB_LIMIT  = 0.10    # [设计] 击穿概率硬约束上限
W_CAP       = 0.25    # [设计] 多空仓位上限（管理层设定）
HY_CAP      = 0.20    # [设计] 高收益占信用仓上限（管理层设定）
TRIG1, TRIG2 = 0.5, 0.8   # [设计] 降档触发线: 年内亏损达安全垫50%减半, 80%清零
CUSH_STRESS = -0.005  # [设计] 稳健性检验中的安全垫压力（管理层校准为-0.5个百分点）

# ===================== 信用端 =====================
IG_SHORT = 0.0525     # [D] IG 1-2年梯队预期总回报(费前,高把握,不含利差观点,已含roll; 2年券循环带)
IG_MID   = 0.0550     # [D] IG 2-3年梯队(3年券循环带)
HY_YTM, HY_ROLL = 0.070689, 0.0029   # [A] JACI HY收益率(2026-07截面) / [B] 滚动收益(坡度外推)
HY_TOTAL = HY_YTM + HY_ROLL
D_IG_SHORT, D_IG_MID, D_HY = 1.50, 2.45, 3.11   # [B][B][A] 利差久期

# ===================== 波动与相关（待历史序列校准）=====================
VOL_SPR_IG, VOL_SPR_HY = 0.0015, 0.0043   # [C] 利差月波动 15bp / 43bp
RHO_IG_HY  = 0.8                          # [C] IG-HY利差相关
VOL_RATE   = 0.0023                       # [C] 利率月波动 23bp

# ===================== 多空策略（头号假设, 待基金审计净值）=====================
LS = dict(mu=0.10, vol=0.09, rho=0.30)    # [C] 收益/波动/与信用因子相关(因子层口径)

# ===================== 费用（仅用于费后换算, 不进模拟）=====================
MGMT_FEE, SUB_FEE = 0.009, 0.010          # [设计占位] 费率未定; 仅供费后换算, 拍板后改此处

# ===================== 模拟设置 =====================
N_PATHS, N_MONTHS, SEED = 20_000, 36, 11
W_GRID = np.round(np.arange(0.05, 0.501, 0.05), 2)

def _cfg(ig, igd, why):
    return dict(cushion=(1-why)*ig + why*HY_TOTAL, wig=1-why, igd=igd, why=why)

CONFIGS = {   # 四种信用配置(HY均不超过上限20%)
    'P_纯IG短':  _cfg(IG_SHORT, D_IG_SHORT, 0.0),
    'Q_9010短': _cfg(IG_SHORT, D_IG_SHORT, 0.1),
    'K_8020短': _cfg(IG_SHORT, D_IG_SHORT, 0.2),
    'M_8020中': _cfg(IG_MID,   D_IG_MID,   0.2),
}
CFG_LABEL = {'P_纯IG短':'纯IG，IG 1-2年', 'Q_9010短':'90/10，IG 1-2年',
             'K_8020短':'80/20，IG 1-2年', 'M_8020中':'80/20，IG 2-3年'}

def _returns(c, ls, cush_adj, n, m, seed):
    """生成月度收益矩阵: 四枚独立正态骰子 → 两因子信用 + 多空"""
    rng = np.random.default_rng(seed)
    cu = c['cushion'] + cush_adj
    F, eh, Zr, Zl0 = rng.standard_normal((4, n, m))
    Zh = RHO_IG_HY*F + np.sqrt(1-RHO_IG_HY**2)*eh          # HY骰子(与IG相关0.8, 保方差)
    Zl = ls['rho']*F + np.sqrt(1-ls['rho']**2)*Zl0          # 多空骰子(与信用因子相关0.3)
    wd = c['wig']*c['igd'] + c['why']*D_HY                  # 组合利率久期
    rb = cu/12 - c['wig']*c['igd']*VOL_SPR_IG*F - c['why']*D_HY*VOL_SPR_HY*Zh - wd*VOL_RATE*Zr
    rl = ls['mu']/12 - ls['vol']/np.sqrt(12)*Zl
    return rb, rl, cu

def sim(c, w, ls=LS, use_L4=True, cush_adj=0.0, n=N_PATHS, seed=SEED):
    """统计版: 返回击穿/深亏/达标/期望/触发等指标"""
    rb, rl, cu = _returns(c, ls, cush_adj, n, N_MONTHS, seed)
    worst = np.full(n, 9.9); nav = np.ones(n); trig = np.zeros(n, bool)
    for y in range(3):
        yn = np.ones(n); wl = np.full(n, w)
        for t in range(12):
            yn *= 1 + (1-wl)*rb[:, y*12+t] + wl*rl[:, y*12+t]
            if use_L4:
                wl = np.where(yn < 1-TRIG2*cu, 0.0, np.where(yn < 1-TRIG1*cu, w*0.5, wl))
                trig |= yn < 1-TRIG1*cu
        worst = np.minimum(worst, yn-1); nav *= yn
    ann = nav**(1/3) - 1
    return dict(breach=(worst < BREACH_LINE).mean(), b3=(worst < -0.03).mean(),
                p7=(ann >= 0.07).mean(), p75=(ann >= 0.075).mean(),
                e=ann.mean(), trig=trig.mean())

def sim_nav(c, w, use_L4=True, n=N_PATHS, seed=SEED):
    """路径版: 返回逐月净值矩阵与每条路径最差日历年回报(供绘图)"""
    rb, rl, cu = _returns(c, LS, 0.0, n, N_MONTHS, seed)
    NAV = np.ones((n, N_MONTHS+1)); worst = np.full(n, 9.9)
    for y in range(3):
        wl = np.full(n, w); ys = NAV[:, y*12].copy()
        for t in range(12):
            k = y*12 + t
            NAV[:, k+1] = NAV[:, k]*(1 + (1-wl)*rb[:, k] + wl*rl[:, k])
            yn = NAV[:, k+1]/ys
            if use_L4:
                wl = np.where(yn < 1-TRIG2*cu, 0.0, np.where(yn < 1-TRIG1*cu, w*0.5, wl))
        worst = np.minimum(worst, NAV[:, (y+1)*12]/ys - 1)
    return NAV, worst

SCENARIOS = [  # 稳健性检验: 单一不利扰动
    ('多空波动+20%',  dict(ls=dict(LS, vol=LS['vol']*1.2)), 0.0),
    ('相关性升至0.5', dict(ls=dict(LS, rho=0.5)),           0.0),
    ('安全垫-0.5%',   {},                                    CUSH_STRESS),
    ('多空收益仅7%',  dict(ls=dict(LS, mu=0.07)),            0.0),
]
