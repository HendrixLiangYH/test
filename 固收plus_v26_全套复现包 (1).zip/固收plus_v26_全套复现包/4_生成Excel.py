# -*- coding: utf-8 -*-
"""
第4步: 汇总全部结果为一个Excel工作簿（先运行第1、3步）
  - 参数台账/配置参数/费后换算: Excel公式联动, 改蓝字输入即自动重算
  - 模拟结果(网格/稳健性/降档/持有期/VaR): 蒙特卡洛输出, 以数值存放(Excel无法重跑模拟)
"""
import csv
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.comments import Comment
from engine_v26 import *

FN = 'Arial'
H = Font(name=FN, bold=True, color='FFFFFF'); HF = PatternFill('solid', fgColor='2F5B8F')
BLUE = Font(name=FN, color='0000FF'); BLK = Font(name=FN); GRN = Font(name=FN, color='008000')
BOLD = Font(name=FN, bold=True); YEL = PatternFill('solid', fgColor='FFFF00')
thin = Side(style='thin', color='BFBFBF'); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
PCT1, PCT2, PCT3 = '0.0%;-0.0%;-', '0.00%;-0.00%;-', '0.000%;-0.000%;-'

wb = Workbook()
def sheet(name, headers, widths):
    ws = wb.create_sheet(name)
    for j, h in enumerate(headers, 1):
        c = ws.cell(1, j, h); c.font = H; c.fill = HF; c.alignment = Alignment(horizontal='center', wrap_text=True); c.border = BOX
    for j, w in enumerate(widths, 1): ws.column_dimensions[chr(64+j)].width = w
    ws.freeze_panes = 'A2'; return ws
def put(ws, r, c, v, font=BLK, fmt=None):
    cell = ws.cell(r, c, v); cell.font = font; cell.border = BOX
    if fmt: cell.number_format = fmt
    return cell

# ---------------- 说明 ----------------
ws = wb.active; ws.title = '说明'
lines = ["固收+组合方案 v2.6 —— 结果工作簿", "",
 "推荐配置: 75%信用债(80% IG 2-3年梯队 + 20% 亚洲HY) + 25%亚洲股票多空, 含年内降档机制",
 "口径: 含降档 · 费前(费后换算表除外) · 正态月收益假设 · 随机种子11",
 "", "颜色约定: 蓝字=可修改的输入; 黑字=公式; 绿字=引用其他工作表; 黄底=关键设计参数",
 "参数台账、配置参数、费后换算三张表为公式联动: 改蓝字输入, Excel自动重算安全垫与费后数字。",
 "其余工作表为Python蒙特卡洛模拟输出(数值)。改参数后须重跑Python脚本(1→3→4)才会更新。",
 "", "工作表: 参数台账 | 配置参数 | 网格结果 | 稳健性 | 降档对照 | 持有期对照 | VaR_CVaR | 条件亏损 | 费后换算"]
for i, t in enumerate(lines, 1):
    ws.cell(i, 1, t).font = Font(name=FN, bold=(i == 1), size=14 if i == 1 else 10)
ws.column_dimensions['A'].width = 110

# ---------------- 参数台账 ----------------
P = sheet('参数台账', ['参数', '取值', '单位', '成色', '来源/依据'], [30, 12, 8, 10, 70])
params = [
 ('IG 1-2年梯队预期总回报', IG_SHORT, '%', 'D', '管理人预期总回报: 费前、高把握、不含利差观点、已含滚动收益; 2年券循环带'),
 ('IG 2-3年梯队预期总回报', IG_MID, '%', 'D', '同上; 3年券循环带'),
 ('HY收益率', HY_YTM, '%', 'A', 'JACI HY指数官方截面(2026年7月, 用户提供)'),
 ('HY滚动收益', HY_ROLL, '%', 'B', 'JACI利差期限坡度13bp/久期年 × 期末利差久期约2.26(外推)'),
 ('IG 1-2年利差久期', D_IG_SHORT, '年', 'B', '2年券循环带持仓平均久期'),
 ('IG 2-3年利差久期', D_IG_MID, '年', 'B', '3年券循环带持仓平均久期'),
 ('HY利差久期', D_HY, '年', 'A', 'JACI HY指数官方加权久期'),
 ('IG利差月波动', VOL_SPR_IG, '%', 'C', '量级判断(年化约50bp), 待FRED历史序列校准'),
 ('HY利差月波动', VOL_SPR_HY, '%', 'C', '量级判断(年化约150bp), 待校准'),
 ('IG-HY利差相关', RHO_IG_HY, '', 'C', '量级判断, 待两利差历史序列实测'),
 ('利率月波动', VOL_RATE, '%', 'C', '量级判断(年化约80bp), 待财政部日频序列校准'),
 ('多空预期收益', LS['mu'], '%', 'C', '亚洲对冲基金指数中枢约12% − 2%数据库偏差(Malkiel & Saha 2005)'),
 ('多空波动', LS['vol'], '%', 'C', '报告波动约6.5% × 1.4去平滑(Getmansky, Lo & Makarov 2004)'),
 ('多空-信用因子相关', LS['rho'], '', 'C', '因子层口径(资产层实际约0.18); 兼任尽调红线, 待基金净值实测'),
 ('击穿判定线', BREACH_LINE, '%', '设计', '任一日历年总回报低于此值即击穿'),
 ('击穿概率上限', PROB_LIMIT, '%', '设计', '硬约束, 字典序一票否决'),
 ('多空仓位上限', W_CAP, '%', '设计', '管理层设定'),
 ('HY占信用仓上限', HY_CAP, '%', '设计', '管理层设定'),
 ('降档触发线1(安全垫比例)', TRIG1, '', '设计', '年内亏损达安全垫此比例时多空减半'),
 ('降档触发线2(安全垫比例)', TRIG2, '', '设计', '年内亏损达安全垫此比例时多空清零'),
 ('稳健性安全垫压力', CUSH_STRESS, '%', '设计', '管理层校准为−0.5个百分点'),
 ('管理费(年)', MGMT_FEE, '%', '设计占位', '费率未定, 仅用于费后换算'),
 ('认购费(一次性)', SUB_FEE, '%', '设计占位', '费率未定, 仅用于费后换算'),
]
ROW = {}
for i, (nm, v, u, g, src) in enumerate(params, 2):
    put(P, i, 1, nm)
    fmt = '0.00%' if u == '%' else '0.00'
    c = put(P, i, 2, v, BLUE, fmt)
    if g.startswith('设计'): c.fill = YEL
    put(P, i, 3, u); put(P, i, 4, g); put(P, i, 5, src)
    ROW[nm] = i
r0 = len(params) + 3
P.cell(r0, 1, '成色: A=实测  B=半实测  C=量级判断(模型软肋)  D=管理人预期  设计=产品委员会拍板项').font = Font(name=FN, italic=True)
ref = lambda nm: f"参数台账!$B${ROW[nm]}"

# ---------------- 配置参数(公式联动) ----------------
CF = sheet('配置参数', ['配置', 'IG收益', 'IG久期', 'HY占比', '安全垫(公式)', '组合利差久期(公式)', '月度滴灌(公式)'],
           [20, 11, 10, 9, 14, 18, 15])
cfg_rows = [('纯IG，IG 1-2年', 'IG 1-2年梯队预期总回报', 'IG 1-2年利差久期', 0.0),
            ('90/10，IG 1-2年', 'IG 1-2年梯队预期总回报', 'IG 1-2年利差久期', 0.1),
            ('80/20，IG 1-2年', 'IG 1-2年梯队预期总回报', 'IG 1-2年利差久期', 0.2),
            ('80/20，IG 2-3年（推荐）', 'IG 2-3年梯队预期总回报', 'IG 2-3年利差久期', 0.2)]
for i, (nm, ig, igd, hy) in enumerate(cfg_rows, 2):
    put(CF, i, 1, nm, BOLD if '推荐' in nm else BLK)
    put(CF, i, 2, f"={ref(ig)}", GRN, '0.00%'); put(CF, i, 3, f"={ref(igd)}", GRN, '0.00')
    put(CF, i, 4, hy, BLUE, '0%')
    put(CF, i, 5, f"=(1-D{i})*B{i}+D{i}*({ref('HY收益率')}+{ref('HY滚动收益')})", BLK, '0.00%')
    put(CF, i, 6, f"=(1-D{i})*C{i}+D{i}*{ref('HY利差久期')}", BLK, '0.00')
    put(CF, i, 7, f"=E{i}/12", BLK, '0.000%')
CF.cell(7, 1, '安全垫 = (1−HY占比)×IG收益 + HY占比×(HY收益率+HY滚动收益); IG收益已含滚动收益, 不再另加。').font = Font(name=FN, italic=True)

# ---------------- 模拟结果表 ----------------
LBL = {'P_纯IG短':'纯IG，IG 1-2年','Q_9010短':'90/10，IG 1-2年','K_8020短':'80/20，IG 1-2年','M_8020中':'80/20，IG 2-3年'}
G = sheet('网格结果', ['信用配置', '多空仓位', '击穿概率(年度为负)', 'P(年亏>3%)', 'P(年化≥7%)', 'P(年化≥7.5%)', '期望年化', '降档触发率'],
          [18, 10, 18, 12, 12, 13, 11, 12])
for i, r in enumerate(csv.DictReader(open('grid_v26.csv', encoding='utf-8-sig')), 2):
    put(G, i, 1, LBL[r['cfg']]); put(G, i, 2, float(r['w']), BLK, '0%')
    for j, k in enumerate(['breach','b3','p7','p75','e','trig'], 3):
        put(G, i, j, float(r[k]), BLK, PCT2 if k != 'b3' else PCT3)
R = sheet('稳健性', ['不利扰动情景', '满足约束的最大多空仓位'], [22, 24])
for i, r in enumerate(list(csv.reader(open('robust_v26.csv', encoding='utf-8-sig')))[1:], 2):
    put(R, i, 1, r[0]); put(R, i, 2, float(r[1]), BLK, '0%')
put(R, 7, 1, '推荐仓位(取最小值)', BOLD); put(R, 7, 2, '=MIN(B2:B5)', BOLD, '0%')
L = sheet('降档对照', ['多空仓位', '年度为负(有降档)', '年度为负(无降档)', '年亏>3%(有)', '年亏>3%(无)', 'P(≥7%)(有)', 'P(≥7%)(无)', '深亏降幅(公式)'],
          [10, 16, 16, 13, 13, 12, 12, 15])
for i, r in enumerate(csv.DictReader(open('l4_v26.csv', encoding='utf-8-sig')), 2):
    put(L, i, 1, float(r['w']), BLK, '0%')
    for j, k in enumerate(['b0_on','b0_off','b3_on','b3_off','p7_on','p7_off'], 2):
        put(L, i, j, float(r[k]), BLK, PCT2)
    put(L, i, 8, f"=IF(E{i}=0,0,1-D{i}/E{i})", BLK, '0%')
HD = sheet('持有期对照', ['指标', '一年就走', '拿满三年', '谁占优'], [30, 12, 12, 10])
for i, r in enumerate(list(csv.reader(open('risk_holding_v26.csv', encoding='utf-8-sig')))[1:], 2):
    put(HD, i, 1, r[0]); put(HD, i, 2, float(r[1]), BLK, PCT2); put(HD, i, 3, float(r[2]), BLK, PCT3); put(HD, i, 4, r[3])
n = i + 1; put(HD, n, 1, '资金锁定时间'); put(HD, n, 2, '1年'); put(HD, n, 3, '3年'); put(HD, n, 4, '一年')
V = sheet('VaR_CVaR', ['持有年数', '指标', '持有期总回报', '年化'], [10, 16, 15, 12])
for i, r in enumerate(list(csv.reader(open('risk_varcvar_v26.csv', encoding='utf-8-sig')))[1:], 2):
    put(V, i, 1, int(r[0])); put(V, i, 2, r[1]); put(V, i, 3, float(r[2]), BLK, PCT2)
    put(V, i, 4, float(r[3]) if r[3] not in ('', 'None') else '—', BLK, PCT2)
CL = sheet('条件亏损', ['指标(一年期, 费前, 亏损年内)', '数值'], [30, 12])
for i, r in enumerate(list(csv.reader(open('risk_lossdist_v26.csv', encoding='utf-8-sig')))[1:], 2):
    put(CL, i, 1, r[0]); v = float(r[1]); put(CL, i, 2, int(v) if r[0] == '亏损样本数' else v, BLK, None if r[0] == '亏损样本数' else PCT2)

# ---------------- 费后换算(公式联动) ----------------
FE = sheet('费后换算', ['项目', '费前(模拟值)', '费后(公式)', '说明'], [30, 14, 14, 50])
hold = {r[0]: r for r in list(csv.reader(open('risk_holding_v26.csv', encoding='utf-8-sig')))[1:]}
e1 = float(hold['期望收益(费前)'][1]); e3 = float(hold['期望收益(费前)'][2])
put(FE, 2, 1, '一年持有: 期望收益'); put(FE, 2, 2, e1, BLK, PCT2)
put(FE, 2, 3, f"=B2-{ref('管理费(年)')}-{ref('认购费(一次性)')}", BLK, PCT2); put(FE, 2, 4, '管理费+认购费全额由一年承担')
put(FE, 3, 1, '三年持有: 年化期望收益'); put(FE, 3, 2, e3, BLK, PCT2)
put(FE, 3, 3, f"=B3-{ref('管理费(年)')}-{ref('认购费(一次性)')}/3", BLK, PCT2); put(FE, 3, 4, '认购费摊三年')
put(FE, 5, 1, '注: 费用为确定性左移, 期望可直接相减; 费后亏损概率需重跑第3步(已在持有期对照表给出)。', Font(name=FN, italic=True))

wb.save('固收plus_v26_结果汇总.xlsx')
print('[Excel] 固收plus_v26_结果汇总.xlsx 已生成')
