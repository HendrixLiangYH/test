# -*- coding: utf-8 -*-
"""第2步: 读CSV并重放净值路径 → 报告全部七张图（先运行第1步）"""
import csv, glob
import numpy as np
import matplotlib; matplotlib.use('Agg')
from matplotlib import font_manager as fm
import matplotlib.pyplot as plt
from engine_v26 import *

# 中文字体自适应(Linux/Windows/Mac)
for pat in ['/usr/share/fonts/opentype/noto/NotoSansCJK*', '/usr/share/fonts/**/*CJK*',
            'C:/Windows/Fonts/msyh*', '/System/Library/Fonts/PingFang*', '/System/Library/Fonts/Hiragino*']:
    for f in glob.glob(pat, recursive=True):
        try: fm.fontManager.addfont(f)
        except Exception: pass
for nm in ['Noto Sans CJK JP','Noto Sans CJK SC','Microsoft YaHei','PingFang SC','Hiragino Sans GB','SimHei']:
    if any(ft.name == nm for ft in fm.fontManager.ttflist):
        plt.rcParams['font.family'] = nm; break
plt.rcParams['axes.unicode_minus'] = False; plt.rcParams['figure.dpi'] = 110

REC, W_REC = 'M_8020中', 0.25
C = CONFIGS[REC]; cu = C['cushion']; x = np.arange(N_MONTHS+1)
rows = list(csv.DictReader(open('grid_v26.csv', encoding='utf-8-sig')))
def sl(cfg):
    s = [r for r in rows if r['cfg'] == cfg]; return [float(r['w']) for r in s], s
YL = '击穿概率（任一日历年为负）'

# fig1 净值扇形图
NAV, _ = sim_nav(C, W_REC)
pct = np.percentile(NAV, [5,25,50,75,95], axis=0)
fig, ax = plt.subplots(figsize=(8,4.5))
ax.fill_between(x, pct[0], pct[4], alpha=0.18, color='#2F5B8F', label='5–95百分位')
ax.fill_between(x, pct[1], pct[3], alpha=0.35, color='#2F5B8F', label='25–75百分位')
ax.plot(x, pct[2], color='#2F5B8F', lw=2, label='中位数')
ax.axhline(1.0, color='gray', ls='--', lw=1, label='期初本金')
ax.set_xlabel('月份'); ax.set_ylabel('净值（期初=1）')
ax.set_title('组合净值分布：20,000条三年模拟路径（信用75% / 多空25%）')
ax.legend(loc='upper left', fontsize=9); ax.grid(alpha=0.25)
plt.tight_layout(); plt.savefig('fig1_净值扇形图.png'); plt.close()

# fig2 权衡曲线
ws, sM = sl(REC); _, sK = sl('K_8020短')
fig, ax1 = plt.subplots(figsize=(8,4.5))
ax1.plot(ws, [float(r['breach']) for r in sM], 'o-', color='#C1440E', lw=2, label='击穿概率（左轴）')
ax1.axhline(PROB_LIMIT, color='#C1440E', ls=':', lw=1.5)
ax1.text(0.06, PROB_LIMIT+0.003, f'约束上限 {PROB_LIMIT:.0%}', color='#C1440E', fontsize=9)
ax1.set_xlabel('多空仓位'); ax1.set_ylabel(YL); ax1.set_ylim(0, 0.17)
ax2 = ax1.twinx(); ax2.plot(ws, [float(r['p7']) for r in sM], 's-', color='#1D6F5C', lw=2, label='P(年化≥7%)（右轴）')
ax2.set_ylabel('P(年化≥7%)'); ax2.set_ylim(0.2, 0.66)
ax1.axvline(W_REC, color='gray', ls='--', lw=1); ax1.text(W_REC+0.005, 0.145, f'推荐仓位 {W_REC:.0%}', fontsize=9)
ax1.set_title('多空仓位与击穿概率、目标达成率的关系（80/20配比，IG 2-3年梯队）')
l1,b1 = ax1.get_legend_handles_labels(); l2,b2 = ax2.get_legend_handles_labels()
ax1.legend(l1+l2, b1+b2, loc='center right', fontsize=9); ax1.grid(alpha=0.25)
plt.tight_layout(); plt.savefig('fig2_权衡曲线.png'); plt.close()

# fig3 期限梯队对比
fig, ax = plt.subplots(figsize=(8,4.2))
ax.plot(ws, [float(r['breach']) for r in sK], 'o-', color='#1D6F5C', lw=2,
        label=f"IG 1-2年梯队（安全垫{CONFIGS['K_8020短']['cushion']:.2%}，IG利差久期{D_IG_SHORT:.2f}）")
ax.plot(ws, [float(r['breach']) for r in sM], 's--', color='#C1440E', lw=2,
        label=f"IG 2-3年梯队（安全垫{cu:.2%}，IG利差久期{D_IG_MID:.2f}）")
ax.axhline(PROB_LIMIT, color='gray', ls=':', lw=1.5); ax.text(0.06, PROB_LIMIT+0.003, f'约束上限 {PROB_LIMIT:.0%}', fontsize=9)
ax.set_xlabel('多空仓位'); ax.set_ylabel(YL)
ax.set_title('两种IG期限梯队的击穿概率对比（均为80/20配比，分腿模拟）')
ax.legend(fontsize=9); ax.grid(alpha=0.25)
plt.tight_layout(); plt.savefig('fig3_久期对比.png'); plt.close()

# fig4 稳健性
rob = [r for i, r in enumerate(csv.reader(open('robust_v26.csv', encoding='utf-8-sig'))) if i > 0]
names = [r[0] for r in rob]; vals = [float(r[1]) for r in rob]
fig, ax = plt.subplots(figsize=(8,3.8))
ax.barh(names, vals, color=['#2F5B8F' if v >= W_REC else '#C1440E' for v in vals], alpha=0.85)
ax.axvline(W_REC, color='black', ls='--', lw=1.5); ax.text(W_REC+0.003, len(names)-0.6, f'推荐仓位 {W_REC:.0%}', fontsize=9)
for i, v in enumerate(vals): ax.text(v+0.004, i, f'{v:.0%}', va='center', fontsize=9)
ax.set_xlabel('满足击穿约束的最大多空仓位'); ax.set_xlim(0, 0.42)
ax.set_title('参数不利扰动下的可行仓位上限')
plt.tight_layout(); plt.savefig('fig4_稳健性.png'); plt.close()

# fig5 降档路径示例
ytd = NAV[:, 1:13]/NAV[:, 0:1]
cand = np.where(ytd.min(axis=1) < 1-0.55*cu)[0]; idx = cand[np.argmax(NAV[cand, -1])]
tm = int(np.argmax(NAV[idx, 1:13]/NAV[idx, 0] < 1-TRIG1*cu)) + 1
fig, ax = plt.subplots(figsize=(8,4.2))
ax.plot(x, NAV[idx], color='#2F5B8F', lw=2)
ax.plot(tm, NAV[idx, tm], 'v', color='#C1440E', ms=11)
ax.annotate(f'第{tm}月：年内亏损达安全垫50%\n多空仓位由25%降至12.5%', (tm, NAV[idx, tm]),
            xytext=(tm+3, NAV[idx, tm]-0.018), fontsize=9, arrowprops=dict(arrowstyle='->'))
ax.axhline(1.0, color='gray', ls='--', lw=1)
ax.axhline(1-TRIG1*cu, color='#C1440E', ls=':', lw=1); ax.text(29, 1-TRIG1*cu+0.002, '降档触发线', fontsize=8, color='#C1440E')
ax.set_xlabel('月份'); ax.set_ylabel('净值'); ax.set_title('年内降档机制示例：一条触发降档的模拟路径'); ax.grid(alpha=0.25)
plt.tight_layout(); plt.savefig('fig5_L4样本路径.png'); plt.close()

# fig6 四配置对比
cols = {'P_纯IG短':'#6B7280','Q_9010短':'#1D6F5C','K_8020短':'#2F5B8F','M_8020中':'#C1440E'}
fig, (a, b) = plt.subplots(1, 2, figsize=(11,4.4))
for cn, co in cols.items():
    _, s = sl(cn)
    a.plot(ws, [float(r['breach']) for r in s], 'o-', color=co, lw=1.8, ms=4, label=CFG_LABEL[cn])
    b.plot(ws, [float(r['p7']) for r in s], 'o-', color=co, lw=1.8, ms=4, label=CFG_LABEL[cn])
a.axhline(PROB_LIMIT, color='gray', ls=':', lw=1.5)
a.set_xlabel('多空仓位'); a.set_ylabel(YL); a.legend(fontsize=8); a.grid(alpha=0.25); a.set_title('四种信用配置的击穿概率')
b.set_xlabel('多空仓位'); b.set_ylabel('P(年化≥7%)'); b.legend(fontsize=8); b.grid(alpha=0.25); b.set_title('四种信用配置的7%达标率')
plt.tight_layout(); plt.savefig('fig6_配置对比.png'); plt.close()

# fig7 降档对照
l4 = list(csv.DictReader(open('l4_v26.csv', encoding='utf-8-sig'))); wx = [float(r['w']) for r in l4]
fig, (a, b) = plt.subplots(1, 2, figsize=(11,4.4))
a.plot(wx, [float(r['b0_on']) for r in l4], 'o-', color='#C1440E', lw=2, label='年度为负（有降档）')
a.plot(wx, [float(r['b0_off']) for r in l4], 's--', color='#C1440E', lw=1.4, alpha=0.65, label='年度为负（无降档）')
a.plot(wx, [float(r['b3_on']) for r in l4], 'o-', color='#2F5B8F', lw=2, label='年亏>3%（有降档）')
a.plot(wx, [float(r['b3_off']) for r in l4], 's--', color='#2F5B8F', lw=1.4, alpha=0.65, label='年亏>3%（无降档）')
a.set_xlabel('多空仓位'); a.set_ylabel('概率'); a.legend(fontsize=8); a.grid(alpha=0.25)
a.set_title('降档机制对两档年度亏损概率的影响')
_, wo = sim_nav(C, 0.35, True); _, wf = sim_nav(C, 0.35, False)
bins = np.linspace(-12, 10, 60)
b.hist(wf*100, bins=bins, alpha=0.45, color='#C1440E', label='无降档')
b.hist(wo*100, bins=bins, alpha=0.55, color='#2F5B8F', label='有降档')
b.axvline(BREACH_LINE*100, color='gray', ls='--', lw=1)
b.set_xlabel('最差日历年回报（%）'); b.set_ylabel('路径数'); b.legend(fontsize=9); b.set_xlim(-12, 8)
b.set_title('最差年份回报分布（多空仓位35%）')
plt.tight_layout(); plt.savefig('fig7_L4对照.png'); plt.close()
print('[绘图] 7张图已生成')
