# -*- coding: utf-8 -*-
"""
第3步: 推荐配置的持有期与亏损深度分析（20万条路径）
  [A] 单年期精确指标 + 解析法独立验证   [B] 持有期对照总表(一年 vs 三年)
  [C] 条件亏损分布                    [D] 持有1/2/3年 VaR / CVaR
  [E] 费后换算
产出: risk_holding_v26.csv / risk_varcvar_v26.csv / risk_lossdist_v26.csv  （约1-2分钟, 内存约300MB）
口径: 推荐配置(80/20, IG 2-3年梯队, 多空25%)·含降档·费前(除费后行)·正态假设·种子11
"""
import csv
import numpy as np
from math import erf, sqrt
from engine_v26 import *
from engine_v26 import _returns

REC, W_LS, N_BIG = 'M_8020中', 0.25, 200_000      # 内存不足可把N_BIG降为50_000
C = CONFIGS[REC]
rb, rl, cu = _returns(C, LS, 0.0, N_BIG, 36, SEED)
nav = np.ones(N_BIG); years, snaps, trigs = [], {}, []
for y in range(3):
    yn = np.ones(N_BIG); wl = np.full(N_BIG, W_LS); tg = np.zeros(N_BIG, bool)
    for t in range(12):
        yn *= 1 + (1-wl)*rb[:, y*12+t] + wl*rl[:, y*12+t]
        tg |= yn < 1-TRIG1*cu
        wl = np.where(yn < 1-TRIG2*cu, 0.0, np.where(yn < 1-TRIG1*cu, W_LS*0.5, wl))
    years.append(yn-1); nav *= yn; snaps[y+1] = nav.copy(); trigs.append(tg)
Y1 = years[0]; ANN = snaps[3]**(1/3) - 1
ANY_NEG = np.min(np.array(years), axis=0) < 0; ANY_TRIG = trigs[0] | trigs[1] | trigs[2]

print("="*60); print("[A] 单年期精确指标 (第一年, 含降档, 费前)"); print("="*60)
p = (Y1 < 0).mean()
print(f"  P(第一年<0) = {p:.3%} (95%CI ±{1.96*np.sqrt(p*(1-p)/N_BIG):.3%})   期望 = {Y1.mean():.3%}")
print(f"  P(≥7%)={np.mean(Y1>=0.07):.2%}  中位{np.median(Y1):.2%}  5%分位{np.percentile(Y1,5):.2%}  95%分位{np.percentile(Y1,95):.2%}")
a=C['wig']*C['igd']*VOL_SPR_IG; b=C['why']*D_HY*VOL_SPR_HY; c=(C['wig']*C['igd']+C['why']*D_HY)*VOL_RATE; s=LS['vol']/np.sqrt(12)
lf=-((1-W_LS)*(a+RHO_IG_HY*b)+W_LS*s*LS['rho']); le=-(1-W_LS)*np.sqrt(1-RHO_IG_HY**2)*b
lr=-(1-W_LS)*c; l0=-W_LS*s*np.sqrt(1-LS['rho']**2)
mu_a=12*((1-W_LS)*cu/12+W_LS*LS['mu']/12); sig_a=np.sqrt(12*(lf**2+le**2+lr**2+l0**2))
print(f"  解析验证(无降档/无复利): 年均值{mu_a:.2%} 年波动{sig_a:.2%} → P(<0)≈{0.5*(1+erf(-mu_a/sig_a/sqrt(2))):.2%}")

f1 = Y1 - MGMT_FEE - SUB_FEE; f3 = ANN - MGMT_FEE - SUB_FEE/3
holding = [
 ("P(年化≥7%)", np.mean(Y1>=0.07), np.mean(ANN>=0.07), "打平"),
 ("期望收益(费前)", Y1.mean(), ANN.mean(), "打平"),
 ("期末本金亏损概率(费前)", np.mean(Y1<0), np.mean(snaps[3]<1), "三年"),
 ("费后本金亏损概率(含认购费)", np.mean(f1<0), np.mean((1+f3)**3<1), "三年"),
 ("平庸结果概率 P(年化≤4%)", np.mean(Y1<=0.04), np.mean(ANN<=0.04), "三年"),
 ("最差1/20 (5%分位)", np.percentile(Y1,5), np.percentile(ANN,5), "三年"),
 ("结果波动(标准差)", Y1.std(), ANN.std(), "三年"),
 ("费后期望(含认购费摊销)", f1.mean(), f3.mean(), "三年"),
 ("经历负收益年份的概率", np.mean(Y1<0), ANY_NEG.mean(), "一年"),
 ("经历降档事件的概率", trigs[0].mean(), ANY_TRIG.mean(), "一年"),
]
print(); print("="*60); print("[B] 持有期对照总表"); print("="*60)
print(f"  {'指标':<24}{'一年就走':>10}{'拿满三年':>10}{'谁占优':>8}")
for nm, v1, v3, who in holding: print(f"  {nm:<24}{v1:>10.2%}{v3:>10.3%}{who:>8}")
print(f"  {'资金锁定时间':<24}{'1年':>10}{'3年':>10}{'一年':>8}")
with open('risk_holding_v26.csv','w',newline='',encoding='utf-8-sig') as f:
    wr=csv.writer(f); wr.writerow(['指标','一年就走','拿满三年','谁占优']); wr.writerows(holding)

loss = Y1[Y1 < 0]
ld = [("亏损样本数", len(loss)), ("平均亏损", -loss.mean()), ("中位亏损", -np.median(loss)),
      ("75%的亏损年不超过", -np.percentile(loss,25)), ("90%的亏损年不超过", -np.percentile(loss,10)),
      ("最惨1%的亏损年约", -np.percentile(loss,1))]
print(); print("="*60); print("[C] 条件亏损分布 (一年期, 费前)"); print("="*60)
for nm, v in ld: print(f"  {nm:<18} {v if isinstance(v,int) else f'{v:.2%}'}")
with open('risk_lossdist_v26.csv','w',newline='',encoding='utf-8-sig') as f:
    wr=csv.writer(f); wr.writerow(['指标','数值']); wr.writerows(ld)

print(); print("="*60); print("[D] VaR / CVaR (持有期总回报口径, 费前, 含降档)"); print("="*60)
vc = []
for h in (1,2,3):
    R = snaps[h]-1; ann = lambda z:(1+z)**(1/h)-1
    vc.append((h,'期望',R.mean(),ann(R.mean()))); vc.append((h,'P(总回报<0)',np.mean(R<0),None))
    print(f"  -- 持有{h}年 -- 期望{R.mean():+.2%}(年化{ann(R.mean()):+.2%})  P(<0)={np.mean(R<0):.3%}")
    for q in (95,99,99.5):
        v=np.percentile(R,100-q); cv=R[R<=v].mean()
        vc += [(h,f'VaR {q}%',v,ann(v)), (h,f'CVaR {q}%',cv,ann(cv))]
        print(f"     VaR{q:>5}%: {v:+.2%}(年化{ann(v):+.2%})   CVaR{q}%: {cv:+.2%}(年化{ann(cv):+.2%})")
with open('risk_varcvar_v26.csv','w',newline='',encoding='utf-8-sig') as f:
    wr=csv.writer(f); wr.writerow(['持有年数','指标','总回报','年化']); wr.writerows(vc)

print(); print("="*60); print("[E] 费后换算 (确定性左移)"); print("="*60)
print(f"  扣管理费{MGMT_FEE:.1%}: 单年期望{Y1.mean()-MGMT_FEE:.2%}, 亏钱概率{np.mean(Y1<MGMT_FEE):.2%}")
print(f"  再含认购费{SUB_FEE:.1%}(一年全扛): 期望{f1.mean():.2%}, 亏钱概率{np.mean(f1<0):.2%}")
